<?php
/**
 * @copyright Copyright 2003-2022 Zen Cart Development Team
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: Zcwilt 2021 Jan 29 New in v1.5.8-alpha $
 */

namespace Zencart\Request;

use Zencart\Traits\Singleton;

class Request
{
    use Singleton;

    protected $paramBag;

    /**
     * The genuine TCP peer address ($_SERVER['REMOTE_ADDR']) as it was at the very start of the
     * request, captured once before any init code (notably init_sessions.php, which overwrites
     * $_SERVER['REMOTE_ADDR'] with the result of zen_get_ip_address()) can mutate it.
     *
     * Trust decisions about client-suppliable forwarded headers (zen_get_ip_address())
     * must be made against this immutable original peer address, never against the live
     * $_SERVER['REMOTE_ADDR'] which may already have been resolved or overwritten earlier in the request.
     * A static property (rather than a define() constant) is used deliberately so
     * it can be reset between PHPUnit test cases running in the same process.
     */
    private static $originalRemoteAddr = null;

    /**
     * Per-request cache of the parsed TRUSTED_PROXIES list. TRUSTED_PROXIES is a defined
     * constant and cannot change during a request, so re-parsing it on every call would be
     * repeated work for an unchanging result. Nullable so null-coalescing assignment can
     * distinguish "not yet computed" from "computed to an empty list".
     */
    private static $trustedProxiesCache = null;

    /**
     * @return mixed|Request
     */
    static function capture()
    {
        $self = self::getInstance();
        $self->paramBag = $_REQUEST;
        return self::getInstance();
    }

    /**
     * @param $key
     * @param null $default
     * @return mixed|null
     */
    public function input($key, $default = null)
    {
        return (isset($this->paramBag[$key]) ? $this->paramBag[$key] : $default);
    }

    /**
     * @param $key
     * @return bool
     */
    public function has($key)
    {
        return (isset($this->paramBag[$key]));
    }

    /**
     * Determine whether the current request was made over HTTPS.
     *
     * Forwarded protocol headers are only authoritative when the genuine TCP peer is a
     * configured trusted proxy. Native web-server HTTPS indicators remain authoritative
     * for direct requests.
     *
     * @since ZC v2.3.0 (backported)
     */
    public static function isSecure(): bool
    {
        $nativelySecure = (isset($_SERVER['HTTPS']) && (strtolower((string) $_SERVER['HTTPS']) === 'on' || $_SERVER['HTTPS'] == '1'))
            || (isset($_SERVER['SCRIPT_URI']) && stripos((string) $_SERVER['SCRIPT_URI'], 'https:') === 0)
            || (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443');
        if ($nativelySecure) {
            return true;
        }

        if (!self::isFromTrustedProxy()) {
            return false;
        }

        $httpsServer = defined('HTTPS_SERVER') ? strtolower(str_replace('https://', '', (string) HTTPS_SERVER)) : '';
        $forwardedHost = strtolower((string) ($_SERVER['HTTP_X_FORWARDED_HOST'] ?? ''));
        $forwardedServer = strtolower((string) ($_SERVER['HTTP_X_FORWARDED_SERVER'] ?? ''));

        return (isset($_SERVER['HTTP_X_FORWARDED_BY']) && str_contains(strtoupper((string) $_SERVER['HTTP_X_FORWARDED_BY']), 'SSL'))
            || ($forwardedHost !== '' && (str_contains(strtoupper($forwardedHost), 'SSL') || ($httpsServer !== '' && str_contains($forwardedHost, $httpsServer))))
            || ($forwardedServer !== '' && $httpsServer !== '' && str_contains($forwardedServer, $httpsServer))
            || (isset($_SERVER['HTTP_X_FORWARDED_SSL']) && ($_SERVER['HTTP_X_FORWARDED_SSL'] == '1' || strtolower((string) $_SERVER['HTTP_X_FORWARDED_SSL']) === 'on'))
            || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && in_array(strtolower((string) $_SERVER['HTTP_X_FORWARDED_PROTO']), ['ssl', 'https'], true))
            || !empty($_SERVER['HTTP_SSLSESSIONID'])
            || (isset($_SERVER['HTTP_X_FORWARDED_PORT']) && $_SERVER['HTTP_X_FORWARDED_PORT'] == '443');
    }

    /**
     * Return the request host without a port.
     *
     * A forwarded host is used only when the genuine TCP peer is trusted. If a proxy chain
     * supplies multiple hosts, the rightmost non-empty value is the one added by the proxy
     * closest to the application.
     *
     * @since ZC v2.3.0 (backported)
     */
    public static function getRequestHost(): string
    {
        $host = (string) ($_SERVER['HTTP_HOST'] ?? '');
        if (self::isFromTrustedProxy() && !empty($_SERVER['HTTP_X_FORWARDED_HOST'])) {
            $forwardedHosts = array_values(array_filter(
                array_map('trim', explode(',', (string) $_SERVER['HTTP_X_FORWARDED_HOST'])),
                static fn(string $forwardedHost): bool => $forwardedHost !== ''
            ));
            if ($forwardedHosts !== []) {
                $host = $forwardedHosts[array_key_last($forwardedHosts)];
            }
        }
        return self::normalizeHost($host);
    }

    /**
     * Determine whether an absolute referer URL belongs to the current request host.
     *
     * Ports are deliberately ignored. This allows Buy Now links to work when HTTP_HOST
     * includes a non-standard port while parse_url() returns only the referer hostname.
     *
     * @since ZC v2.3.0 (backported)
     */
    public static function isInternalReferer(string $referer): bool
    {
        if ($referer === '') {
            return false;
        }
        $refererHost = parse_url($referer, PHP_URL_HOST);
        if (!is_string($refererHost) || $refererHost === '') {
            return false;
        }
        return self::normalizeHost($refererHost) === self::getRequestHost();
    }

    /**
     * Normalize a hostname for comparison, including bracketed IPv6 addresses.
     *
     * @since ZC v2.3.0 (backported)
     */
    private static function normalizeHost(string $host): string
    {
        $host = strtolower(trim($host));
        if (preg_match('/^\[(.*)\](?::\d+)?$/D', $host, $matches)) {
            return $matches[1];
        }
        return preg_replace('/:\d+$/D', '', $host) ?? '';
    }

    /**
     * Return the genuine TCP peer address captured at the start of the request.
     *
     * Lazily captures on first read as a safety net in case captureOriginalRemoteAddr() was not
     * already called during bootstrap. The first captured value remains stable for the request.
     *
     * @since ZC v2.3.0 (backported)
     */
    public static function getOriginalRemoteAddr(): string
    {
        self::captureOriginalRemoteAddr();
        return self::$originalRemoteAddr ?? '';
    }

    /**
     * Capture the genuine TCP peer address once, as early as possible in the request.
     *
     * Null-coalescing assignment makes repeated calls harmless and ensures that a later,
     * possibly already-mutated $_SERVER['REMOTE_ADDR'] cannot replace the original value.
     *
     * @since ZC v2.3.0 (backported)
     */
    public static function captureOriginalRemoteAddr(): void
    {
        self::$originalRemoteAddr ??= ($_SERVER['REMOTE_ADDR'] ?? '');
    }

    /**
     * Determine whether the genuine TCP peer is a configured trusted reverse proxy.
     *
     * @since ZC v2.3.0 (backported)
     */
    public static function isFromTrustedProxy(): bool
    {
        return self::isTrustedProxyAddress(self::getOriginalRemoteAddr());
    }

    /**
     * Determine whether the given address matches a configured trusted reverse proxy.
     *
     * Each TRUSTED_PROXIES entry may be a single IP or a CIDR range such as
     * 173.245.48.0/20. Both IPv4 and IPv6 are supported.
     *
     * @since ZC v2.3.0 (backported)
     */
    public static function isTrustedProxyAddress(string $address): bool
    {
        if ($address === '') {
            return false;
        }
        $trustedProxies = self::getTrustedProxies();
        if ($trustedProxies === []) {
            return false;
        }

        // Compute the candidate's packed address once for all configured entries.
        $addressBin = @inet_pton($address);
        if ($addressBin === false) {
            return false;
        }
        foreach ($trustedProxies as $proxyEntry) {
            if (self::proxyEntryMatchesPeer($addressBin, $proxyEntry)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Return the parsed TRUSTED_PROXIES list, computed once per request.
     *
     * Accepts either an array or a comma-separated string, trims entries, and drops empty entries.
     *
     * @since ZC v2.3.0 (backported)
     */
    public static function getTrustedProxies(): array
    {
        self::$trustedProxiesCache ??= self::parseTrustedProxiesConfig();
        return self::$trustedProxiesCache;
    }

    /**
     * Parse the raw TRUSTED_PROXIES configuration constant into a normalized list.
     *
     * @since ZC v2.3.0 (backported)
     */
    private static function parseTrustedProxiesConfig(): array
    {
        $trustedProxiesConfig = defined('TRUSTED_PROXIES') ? constant('TRUSTED_PROXIES') : '';
        if (is_array($trustedProxiesConfig)) {
            return array_values(array_filter(array_map(static fn($proxy): string => trim((string) $proxy), $trustedProxiesConfig)));
        }
        return array_values(array_filter(array_map('trim', explode(',', (string) $trustedProxiesConfig))));
    }

    /**
     * Resolve the real client address from a forwarded-header chain such as X-Forwarded-For.
     *
     * A client can forge the leftmost entries before the request reaches a trusted proxy.
     * Walk the chain from the right, skip entries that are themselves trusted proxies, and
     * return the first address that is not trusted. If every entry is trusted, or the chain
     * is empty after trimming, fall back to the captured original peer address.
     *
     * @since ZC v2.3.0 (backported)
     */
    public static function resolveClientFromForwardedChain(string $forwardedChain): string
    {
        $hops = array_reverse(array_values(array_filter(array_map('trim', explode(',', $forwardedChain)), static fn(string $hop): bool => $hop !== '')));
        foreach ($hops as $hop) {
            if (!self::isTrustedProxyAddress($hop)) {
                return $hop;
            }
        }
        return self::getOriginalRemoteAddr();
    }

    /**
     * Match one TRUSTED_PROXIES entry, either an exact IP or CIDR range, against a packed address.
     *
     * Exact entries are compared in packed form so equivalent IPv6 text representations match.
     *
     * @since ZC v2.3.0 (backported)
     */
    private static function proxyEntryMatchesPeer(string $peerBin, string $proxyEntry): bool
    {
        if (!str_contains($proxyEntry, '/')) {
            $entryBin = @inet_pton($proxyEntry);
            return $entryBin !== false && $entryBin === $peerBin;
        }
        return self::ipInCidrRange($peerBin, $proxyEntry);
    }

    /**
     * Determine whether a packed IP address falls within an IPv4 or IPv6 CIDR range.
     *
     * Invalid input and address-family mismatches return false.
     *
     * @since ZC v2.3.0 (backported)
     */
    private static function ipInCidrRange(string $ipBin, string $cidr): bool
    {
        $parts = explode('/', $cidr, 2);
        if (count($parts) !== 2 || !ctype_digit($parts[1])) {
            return false;
        }
        [$subnet, $maskBits] = $parts;
        $maskBits = (int) $maskBits;

        $subnetBin = @inet_pton($subnet);
        if ($subnetBin === false || strlen($ipBin) !== strlen($subnetBin)) {
            return false;
        }

        $totalBits = strlen($ipBin) * 8;
        if ($maskBits < 0 || $maskBits > $totalBits) {
            return false;
        }

        $fullBytes = intdiv($maskBits, 8);
        if ($fullBytes > 0 && substr($ipBin, 0, $fullBytes) !== substr($subnetBin, 0, $fullBytes)) {
            return false;
        }

        $remainderBits = $maskBits % 8;
        if ($remainderBits === 0) {
            return true;
        }

        $mask = chr((0xFF << (8 - $remainderBits)) & 0xFF);
        return (ord($ipBin[$fullBytes]) & ord($mask)) === (ord($subnetBin[$fullBytes]) & ord($mask));
    }

    /**
     * Test-only: clear the captured peer address.
     *
     * @internal
     * @since ZC v2.3.0 (backported)
     */
    public static function resetOriginalRemoteAddrForTesting(): void
    {
        self::$originalRemoteAddr = null;
    }

    /**
     * Test-only: clear the cached parsed TRUSTED_PROXIES list.
     *
     * @internal
     * @since ZC v2.3.0 (backported)
     */
    public static function resetTrustedProxiesCacheForTesting(): void
    {
        self::$trustedProxiesCache = null;
    }
}
