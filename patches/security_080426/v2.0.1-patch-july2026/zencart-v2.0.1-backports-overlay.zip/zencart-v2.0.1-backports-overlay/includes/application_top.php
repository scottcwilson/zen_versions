<?php
/**
 * application_top.php Common actions carried out at the start of each page invocation.
 *
 * Initializes common classes & methods. Controlled by an array which describes
 * the elements to be initialised and the order in which that happens.
 * see  {@link  https://docs.zen-cart.com/dev/code/init_system/} for more details.
 * @copyright Copyright 2003-2024 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: DrByte 2024 Feb 19 Modified in v2.0.0-beta1 $
 */

use App\Models\PluginControl;
use App\Models\PluginControlVersion;
use Zencart\FileSystem\FileSystem;
use Zencart\PluginManager\PluginManager;
use Zencart\InitSystem\InitSystem;

// Set session ID
$zenSessionId = 'zenid';
/**
 * inoculate against hack attempts which waste CPU cycles
 */
$contaminated = (isset($_FILES['GLOBALS']) || isset($_REQUEST['GLOBALS'])) ? true : false;
$paramsToAvoid = array('GLOBALS', '_COOKIE', '_ENV', '_FILES', '_GET', '_POST', '_REQUEST', '_SERVER', '_SESSION', 'HTTP_COOKIE_VARS', 'HTTP_ENV_VARS', 'HTTP_GET_VARS', 'HTTP_POST_VARS', 'HTTP_POST_FILES', 'HTTP_RAW_POST_DATA', 'HTTP_SERVER_VARS', 'HTTP_SESSION_VARS');
$paramsToAvoid[] = 'autoLoadConfig';
$paramsToAvoid[] = 'mosConfig_absolute_path';
$paramsToAvoid[] = 'function';
$paramsToAvoid[] = 'hash';
$paramsToAvoid[] = 'main';
$paramsToAvoid[] = 'vars';
foreach($paramsToAvoid as $key) {
  if (isset($_GET[$key]) || isset($_POST[$key]) || isset($_COOKIE[$key])) {
    $contaminated = true;
    break;
  }
}
$paramsToCheck = array($zenSessionId, 'main_page', 'cPath', 'products_id', 'language', 'currency', 'action', 'manufacturers_id', 'pID', 'pid', 'reviews_id', 'filter_id', 'sort', 'number_of_uploads', 'notify', 'page_holder', 'chapter', 'alpha_filter_id', 'typefilter', 'disp_order', 'id', 'key', 'music_genre_id', 'record_company_id', 'set_session_login', 'faq_item', 'edit', 'delete', 'search_in_description', 'dfrom', 'pfrom', 'dto', 'pto', 'inc_subcat', 'payment_error', 'order', 'gv_no', 'pos', 'addr', 'error', 'count', 'error_message', 'info_message', 'cID', 'page', 'credit_class_error_code');
if (!$contaminated) {
    foreach ($paramsToCheck as $key) {
        if (!isset($_GET[$key])) {
            continue;
        }
        if (is_array($_GET[$key])) {
            $contaminated = true;
            break;
        }
        if (stripos((string) $_GET[$key], 'http') === 0 || strpos((string) $_GET[$key], '//') !== false) {
            $contaminated = true;
            break;
        }
        $len = in_array($key, [$zenSessionId, 'error_message', 'payment_error'], true) ? 255 : 43;
        if (strlen((string) $_GET[$key]) > $len) {
            $contaminated = true;
            break;
        }
    }
}

/**
 * Determine the query string as the CLIENT actually sent it, which is not always
 * $_SERVER['QUERY_STRING'].
 *
 * An internal mod_rewrite rewrite replaces QUERY_STRING with the rewritten one,
 * and SEO-URL rulesets routinely synthesize extra parameters while doing so. The
 * stock Ultimate SEO URLs .htaccess, for example, rewrites with
 *   RewriteRule ^(.*)$ index.php?main_page=$1&%{QUERY_STRING} [L]
 * so a request for /products_all.html?main_page=products_all&disp_order=3 reaches
 * PHP with QUERY_STRING = "main_page=products_all.html&main_page=products_all&disp_order=3".
 * That repeated (and differing) main_page is authored by the web server, not the
 * client -- PHP's last-value-wins behaviour is precisely what makes the ruleset
 * work -- so judging it as parameter pollution rejects ordinary catalog requests.
 *
 * REQUEST_URI is left untouched by internal rewrites, so its query portion is the
 * client's own input: the only part an attacker controls, and the only part that
 * any upstream layer (WAF, CDN, log parser) would have parsed differently than PHP.
 * Fall back to QUERY_STRING on SAPIs that do not publish REQUEST_URI.
 *
 * $_GET-based checks are deliberately left operating on the post-rewrite values,
 * so parameters injected by the rewrite are still validated for length and content.
 */
$clientQueryString = $_SERVER['QUERY_STRING'] ?? '';
if (isset($_SERVER['REQUEST_URI'])) {
    $queryDelimiter = strpos($_SERVER['REQUEST_URI'], '?');
    $clientQueryString = $queryDelimiter === false ? '' : substr($_SERVER['REQUEST_URI'], $queryDelimiter + 1);
}

/**
 * Reject excessive query strings and raw control/non-ASCII bytes. Payment and
 * checkout returns receive a larger allowance because off-site providers can
 * legitimately return longer query strings.
 */
if (!$contaminated && $clientQueryString !== '') {
    $longQueryPages = ['checkout_process', 'checkout_payment', 'checkout', 'checkout_one', 'checkout_one_confirmation'];
    $maxQueryLength = in_array($_GET['main_page'] ?? '', $longQueryPages, true) ? 2048 : 256;

    if (strlen($clientQueryString) > $maxQueryLength
        || preg_match('/[\x00-\x1F\x7F-\xFF]/', $clientQueryString)
    ) {
        $contaminated = true;
    }
}

/**
 * Reject HTTP parameter pollution for keys Zen Cart expects to be scalar.
 * PHP silently replaces earlier scalar values and normalizes encoded dots and
 * spaces in parameter names, so inspect and normalize the raw query keys before
 * the database and session systems are initialized. Matching is intentionally
 * case-insensitive. Unknown keys are left alone so plugins can intentionally use
 * repeated GET arrays such as filter[]=value.
 *
 * Operates on the client-supplied query string (see $clientQueryString above) so
 * that duplicates synthesized by a mod_rewrite SEO-URL ruleset are not mistaken
 * for an attack.
 */
if (!$contaminated && $clientQueryString !== '') {
    $protectedScalarKeys = [];
    foreach ($paramsToCheck as $protectedKey) {
        $protectedScalarKeys[strtolower($protectedKey)] = true;
    }

    $seenProtectedKeys = [];
    $querySeparators = (string) ini_get('arg_separator.input');
    $queryPairs = preg_split(
        '/[' . preg_quote($querySeparators !== '' ? $querySeparators : '&', '/') . ']/',
        $clientQueryString
    );

    if ($queryPairs === false) {
        $contaminated = true;
    } else {
        foreach ($queryPairs as $pair) {
            $rawKey = explode('=', $pair, 2)[0];
            if ($rawKey === '') {
                continue;
            }

            $decodedKey = ltrim(urldecode($rawKey), ' ');

            // PHP truncates parameter names at decoded NUL bytes; no control byte is valid key content.
            if (preg_match('/[\x00-\x1F\x7F]/', $decodedKey)) {
                $contaminated = true;
                break;
            }

            $normalizedKey = strtolower(str_replace(['.', ' '], '_', $decodedKey));
            $bracketPosition = strpos($normalizedKey, '[');
            $baseKey = $bracketPosition === false ? $normalizedKey : substr($normalizedKey, 0, $bracketPosition);

            if (!isset($protectedScalarKeys[$baseKey])) {
                continue;
            }

            if ($bracketPosition !== false || isset($seenProtectedKeys[$baseKey])) {
                $contaminated = true;
                break;
            }

            $seenProtectedKeys[$baseKey] = true;
        }
    }
}

unset(
    $paramsToCheck,
    $paramsToAvoid,
    $key,
    $clientQueryString,
    $queryDelimiter,
    $longQueryPages,
    $maxQueryLength,
    $protectedScalarKeys,
    $protectedKey,
    $seenProtectedKeys,
    $querySeparators,
    $queryPairs,
    $pair,
    $rawKey,
    $decodedKey,
    $normalizedKey,
    $bracketPosition,
    $baseKey
);

/**
 * reject catalog-filter params (manufacturers_id, sort, etc.) when supplied for
 * a page confirmed to never legitimately read them, such as checkout pages with
 * spoofed query strings. cPath and products_id are deliberately NOT covered here.
 */
if (!$contaminated) {
    require_once __DIR__ . '/routing_map.php';
    $contaminated = zen_request_has_disallowed_catalog_param($_GET);
}

if ($contaminated)
{
  header('HTTP/1.1 406 Not Acceptable');
  exit(0);
}
unset($contaminated, $len);
/* *** END OF INOCULATION *** */

// if session id is reconfigured, then we want to exclude its use immediately
if ($zenSessionId !== 'zenid') {
    unset($_GET['zenid'], $_GET['amp;zenid'], $_REQUEST['zenid']);
}

/**
 * boolean used to see if we are in the admin script, obviously set to false here.
 */
define('IS_ADMIN_FLAG', false);

/**
 * integer saves the time at which the script started.
 */
define('PAGE_PARSE_START_TIME', microtime());
@ini_set("arg_separator.output","&");
@ini_set("html_errors","0");
/**
 * Ensure minimum PHP version.
 * This is intended to run before any dependencies are required
 * See https://www.zen-cart.com/requirements or run zc_install to see actual requirements!
 */
if (PHP_VERSION_ID < 80002) {
    require 'includes/templates/template_default/templates/tpl_zc_phpupgrade_default.php';
    exit(0);
}

/**
 * Capture the genuine TCP peer address before any other bootstrap code runs.
 *
 * This must happen before init_sessions.php overwrites $_SERVER['REMOTE_ADDR'] with the resolved
 * client IP, so that trust decisions about forwarded headers (zen_get_ip_address()) always see the
 * real proxy/peer address. Request is not autoloadable this early (the psr-4 autoloader is
 * registered further down), so the class and its trait are required explicitly here via
 * __DIR__-relative paths. Nothing above this point reads $_SERVER['REMOTE_ADDR'].
 */
require_once __DIR__ . '/classes/traits/Singleton.php';
require_once __DIR__ . '/classes/Request.php';
\Zencart\Request\Request::captureOriginalRemoteAddr();

/**
 * Set the local configuration parameters - mainly for developers
 */
if (file_exists('includes/local/configure.php')) {
  /**
   * load any local(user created) configure file.
   */
  include('includes/local/configure.php');
}
/**
 * boolean if true the autoloader scripts will be parsed and their output shown. For debugging purposes only.
 */
define('DEBUG_AUTOLOAD', false);
/**
 * set the level of error reporting
 *
 * Note STRICT_ERROR_REPORTING should never be set to true on a production site.
 * It is mainly there to show php warnings during testing/bug fixing phases.
 */
if (DEBUG_AUTOLOAD || (defined('STRICT_ERROR_REPORTING') && STRICT_ERROR_REPORTING == true)) {
  @ini_set('display_errors', TRUE);
  error_reporting(defined('STRICT_ERROR_REPORTING_LEVEL') ? STRICT_ERROR_REPORTING_LEVEL : E_ALL);
} else {
    error_reporting(0);
}

date_default_timezone_set(date_default_timezone_get());

/*
 * Check for a valid system locale, and override if invalid or set to 'C' which means 'unconfigured'
 * It will be overridden later via language-selection operations anyway, but a valid default must be set for zcDate class methods to work
 */
$detected_locale = setlocale(LC_TIME, 0);
if ($detected_locale === false || $detected_locale === 'C') {
    setlocale(LC_TIME, ['en_US', 'en_US.UTF-8', 'en-US', 'en']);
}
if (file_exists('./not_for_release/testFramework/Support/application_testing.php')) {
    require('./not_for_release/testFramework/Support/application_testing.php');
}
/**
 * check for and include load application parameters
 */
if (!defined('ZENCART_TESTFRAMEWORK_RUNNING')) {
    if (file_exists('includes/configure.php')) {
        /**
         * load the main configure file.
         */
        include('includes/configure.php');
    } else if (!defined('DIR_FS_CATALOG') && !defined('HTTP_SERVER') && !defined('DIR_WS_CATALOG') && !defined('DIR_WS_INCLUDES')) {
        $problemString = 'includes/configure.php not found';
        require('includes/templates/template_default/templates/tpl_zc_install_suggested_default.php');
        exit;
    }
}
/**
 * if main configure file doesn't contain valid info (ie: is dummy or doesn't match filestructure, display assistance page to suggest running the installer)
 */
if (!defined('DIR_FS_CATALOG') || !is_dir(DIR_FS_CATALOG.'/includes/classes')) {

    $problemString = 'includes/configure.php file contents invalid.  ie: DIR_FS_CATALOG not valid or not set';
  require('includes/templates/template_default/templates/tpl_zc_install_suggested_default.php');
  exit;
}

/*
 * Reject automated or cross-site Buy Now requests before initializing the application.
 * Forwarded hosts are considered only when the connection came from a configured trusted proxy.
 */
if (isset($_GET['action']) && $_GET['action'] === 'buy_now') {
    $isCrawlerUserAgent = empty($_SERVER['HTTP_USER_AGENT'])
        || preg_match('/bot|crawl|spider|slurp|facebookexternalhit|bingpreview/i', (string) $_SERVER['HTTP_USER_AGENT']);
    $hasInternalReferer = \Zencart\Request\Request::isInternalReferer((string) ($_SERVER['HTTP_REFERER'] ?? ''));

    if ($isCrawlerUserAgent || !$hasInternalReferer) {
        header('HTTP/1.1 406 Not Acceptable');
        exit;
    }
    unset($isCrawlerUserAgent, $hasInternalReferer);
}

/**
 * check for and load system defined path constants
 */
if (file_exists('includes/defined_paths.php')) {
    /**
     * load the system-defined path constants
     */
    require('includes/defined_paths.php');
} else {
    die('ERROR: /includes/defined_paths.php file not found. Cannot continue.');
    exit;
}
require DIR_FS_CATALOG . DIR_WS_FUNCTIONS . 'php_polyfills.php';
require DIR_FS_CATALOG . DIR_WS_FUNCTIONS . 'zen_define_default.php';

/**
 * Register error-handling functions
 */
require DIR_FS_CATALOG . DIR_WS_FUNCTIONS . 'functions_error_handling.php';
zen_enable_error_logging();

/**
 * include the list of extra configure files
 */
foreach (glob(DIR_WS_INCLUDES . 'extra_configures/*.php') ?? [] as $file) {
    include($file);
}
$autoLoadConfig = [];
if (isset($loaderPrefix)) {
 $loaderPrefix = preg_replace('/[^a-z_]/', '', $loaderPrefix);
} else {
  $loaderPrefix = 'config';
}
$loader_file = $loaderPrefix . '.core.php';
require 'includes/initsystem.php';
/**
 * determine install status
 */
if (!defined('ZENCART_TESTFRAMEWORK_RUNNING')) {
    if (((!file_exists('includes/configure.php') && !file_exists('includes/local/configure.php'))) || (DB_TYPE == '') || (!file_exists('includes/classes/db/' . DB_TYPE . '/query_factory.php')) || !file_exists('includes/autoload_func.php')) {
        $problemString = 'includes/configure.php file empty or file not found, OR wrong DB_TYPE set, OR cannot find includes/autoload_func.php which suggests paths are wrong or files were not uploaded correctly';
        require('includes/templates/template_default/templates/tpl_zc_install_suggested_default.php');
        header('location: zc_install/index.php');
        exit;
    }
}
/**
 * psr-4 autoloading
 */
require DIR_FS_CATALOG . DIR_WS_CLASSES . 'vendors/AuraAutoload/src/Loader.php';
require DIR_FS_CATALOG . 'laravel/vendor/autoload.php';
$psr4Autoloader = new \Aura\Autoload\Loader;
$psr4Autoloader->register();
require('includes/psr4Autoload.php');
require DIR_FS_CATALOG . DIR_WS_CLASSES . 'class.base.php';
require DIR_FS_CATALOG . DIR_WS_CLASSES . 'query_cache.php';

$queryCache = new QueryCache();
require DIR_FS_CATALOG . DIR_WS_CLASSES . 'cache.php';
$zc_cache = new cache();

require 'includes/init_includes/init_file_db_names.php';
require 'includes/init_includes/init_database.php';

require DIR_FS_CATALOG . 'includes/application_laravel.php';

$pluginManager = new PluginManager(new PluginControl(), new \App\Models\PluginControlVersion());
$installedPlugins = $pluginManager->getInstalledPlugins();
$pluginManager = new PluginManager(new PluginControl, new App\Models\PluginControlVersion);

$fs = new FileSystem;
$fs->loadFilesFromPluginsDirectory($installedPlugins, 'catalog/includes/extra_configures', '~^[^\._].*\.php$~i');
$fs->loadFilesFromPluginsDirectory($installedPlugins, 'catalog/includes/extra_datafiles', '~^[^\._].*\.php$~i');

foreach ($installedPlugins as $plugin) {
    $namespaceAdmin = 'Zencart\\Plugins\\Admin\\' . ucfirst($plugin['unique_key']);
    $namespaceCatalog = 'Zencart\\Plugins\\Catalog\\' . ucfirst($plugin['unique_key']);
    $filePath = DIR_FS_CATALOG . 'zc_plugins/' . $plugin['unique_key'] . '/' . $plugin['version'] . '/';
    $filePathAdmin = $filePath . 'classes/admin';
    $filePathCatalog = $filePath . 'classes/';
    $psr4Autoloader->addPrefix($namespaceAdmin, $filePathAdmin);
    $psr4Autoloader->addPrefix($namespaceCatalog, $filePathCatalog);
}


$autoLoadConfig = array();
if (isset($loaderPrefix)) {
    $loaderPrefix = preg_replace('/[^a-z_]/', '', $loaderPrefix);
} else {
    $loaderPrefix = 'config';
}
$loader_file = $loaderPrefix . '.core.php';
$initSystem = new InitSystem('catalog', $loaderPrefix, new FileSystem, $pluginManager, $installedPlugins);

if (defined('DEBUG_AUTOLOAD') && DEBUG_AUTOLOAD == true) $initSystem->setDebug(true);

$loaderList = $initSystem->loadAutoLoaders();

$initSystemList = $initSystem->processLoaderList($loaderList);

require DIR_FS_CATALOG . 'includes/autoload_func.php';
/**
 * load the counter code
**/
if (empty($spider_flag)) {
// counter and counter history
  require(DIR_WS_INCLUDES . 'counter.php');
}
// get customers unique IP that paypal does not touch
$customers_ip_address = $_SERVER['REMOTE_ADDR'];
if (!isset($_SESSION['customers_ip_address'])) {
  $_SESSION['customers_ip_address'] = $customers_ip_address;
}
